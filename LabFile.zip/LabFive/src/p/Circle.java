package p;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*Abd Elswify
 * 
 * Class Definition: This class's purpose is to override the super methods of the parent Shape class to make a Circle
 */
public class Circle extends Shape{
	public int r;
	
	public Circle(int a, int b) {
		super(a, b);
		
	}
	public Circle(int a, int b, int r) {
		super(a, b);
		this.r = r;
	}
	//This method is meant to calculate the area of the pertaining circle shape
	@Override public double getArea() {
		return Math.PI * r * r;
	}
	//This method is meant to draw a painted circle, and then a series of other outlined circles
	@Override public void draw( Graphics g ){
		Graphics2D g2d = (Graphics2D) g;	
		final int x = getX();
		final int y = getY();	
		g2d.setColor( Color.GREEN );
		g2d.setPaint( new GradientPaint( x, y, Color.GREEN, x, y, Color.BLACK, true) );
		g2d.fillOval(x, y, r, r);
		for(int i = 1; i < 13; i++) {
			g2d.drawOval(super.getX(),super.getY(), r*i, r*i);
		}
	}
	public double getRadius() {
		return r;
	}
	public void setRadius(int r) {
		this.r = r;
	}
}
