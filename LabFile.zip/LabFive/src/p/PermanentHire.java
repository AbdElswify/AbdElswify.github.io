package p;

public class PermanentHire extends SalariedWorker {
	public static final double HIRE_MONTHLY = 16000;
	public PermanentHire(String name, int social){
		super(name, social);
	}
	
	public PermanentHire(String name, int social, double pay) {
		super(name, social, pay);
	}
	@Override public double calculateWeeklyPay() {
		return HIRE_MONTHLY/4;
	}
}
