package p;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*Abd Elswify
 * 
 * Class Definition: This class's purpose is to override the super methods of the parent Shape class to make a Triangle
 */
public class Triangle extends Shape {
	
	int[] xPoints;
	int[] yPoints;

	public Triangle(int[] a, int[] b) {
		super(a,b);
	}
	//This method is meant to calculate the area of the pertaining Triangle shape
	@Override public double getArea() {
		return .5 * ((getXPoints()[0] - getXPoints()[1])/(getYPoints()[0] - getYPoints()[1])) * ((getXPoints()[1] - getXPoints()[2])/(getYPoints()[1] - getYPoints()[2]));
	}
	//This method is meant to simply draw an outlined triangle of randomly generated lengths
	@Override public void draw( Graphics g ){
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor( Color.black );
		g2d.drawPolygon(getXPoints(), getYPoints(), 3);
	}
	public int[] getXP() {
		return xPoints;
	}
	public void setXP(int[] r) {
		this.xPoints = r;
	}
	public int[] getHP() {
		return yPoints;
	}
	public void setHP(int[] r) {
		this.yPoints = r;
	}
}
