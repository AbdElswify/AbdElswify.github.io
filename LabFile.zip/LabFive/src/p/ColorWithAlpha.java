package p;

public class ColorWithAlpha extends SimpleColor {
	SimpleColor RGB = new SimpleColor();
	public int alpha;
	
	public int getAlpha() {
		return alpha;
	}

	public void setAlpha(int r) {
		assert (0 <= r) && (r <= 255): "Value out of bounds";
		this.alpha = r;
	}
	
	public ColorWithAlpha(int a) {
		this.alpha = a;
		RGB.setColor(0,0,0);
	}
	public ColorWithAlpha(int r, int g, int b,int a) {
		super(r,g,b);
		RGB.setColor(r,g,b);
		this.alpha = a;
	}
	public ColorWithAlpha(ColorWithAlpha object) {
		RGB = object;
		this.alpha = object.alpha;
	}
	@Override public String toString() { 
		return  " R: " + RGB.getR() + " G: " + RGB.getG() + " B: " + RGB.getB() + " alpha:"+ alpha;
	}
	public boolean equals(ColorWithAlpha o) {
		System.out.println(" R: " + RGB.getR() + " G: " + RGB.getG() + " B: " + RGB.getB() + " alpha:"+ alpha);
		System.out.println(" R: " + o.getR() + " G: " + o.RGB.getG() + " B: " + o.RGB.getB() + " alpha:"+ o.alpha);
		if (RGB.equals(o.RGB) && (alpha == o.getAlpha())) {
			return true;
		}
		return false;
	}
}
