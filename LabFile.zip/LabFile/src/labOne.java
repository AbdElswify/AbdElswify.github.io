
public class labOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
