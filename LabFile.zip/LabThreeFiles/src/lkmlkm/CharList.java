package lkmlkm;

public class CharList {
	private char[] arr;
	private int numList;
	public CharList() {
		
	}
	public CharList(String startStr) { //use string to set up internals
	
	}
	public CharList(CharList other) { //copy c�tor; be sure to check for null input
	
	}
	public void add(char next) { //Could we make this so it dynamically grows to accommodate more than 100 elements?
	
	}
	public char get(int index) {
		return arr[index];
	}
	@Override public String toString() {
		String str = "";
		for (int i = 0; i < arr.length; i++) {
			str += arr[i];
		}
		return str;
	}
	//Return a string that is the concatenated result of combining every character in your char array.
	public boolean equals(Object other) {
	if( other == null || ! (other instanceof CharList )) return false; //follow this pattern to check for null and verify class types
	CharList that = (CharList) other; //use this v.s. that from this point on
	//Two strings are the same if they share the same length and the same characters
	return true;
	}
}
