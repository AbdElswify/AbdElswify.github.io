package lkmlkm;

public class PointTwoD {

	
		private int x;
		private int y;
		
		public static void main(String[] args) {
			PointTwoD a = new PointTwoD();
		    a.setX(5);
		    a.setY(2);
		    System.out.println("Point at (" + a.getX() + ", " + a.getY() ); 
		    a.translate(-1,-1);
		    System.out.println("Point at (" + a.getX() + ", " + a.getY() );
		    a.resetToOrigin();
		    System.out.println("Point at (" + a.getX() + ", "  + a.getY() ); 
		    PointTwoD b = new PointTwoD();
		    PointTwoD c = new PointTwoD();
		    System.out.println(b.toString());
		    System.out.println(c); //Question: why don�t I need c.toString() here?
		    System.out.println("Are b and c equal:" + b.equals(c));
		}
		public void setXAndY(int nX, int nY) {
			this.x = nX;
			this.y = nY;
		}
		public void setX(int nX) {
			this.x = nX;
		}
		public void setY(int nY) {
			this.y = nY;
		}
		public int getX() {
			return x; 
		}
		public int getY() {
			return y;
		}
		public void resetToOrigin() {
			x = 0;
			y = 0;
		}
		public void translate(int dx, int dy) {
			this.x += dx;
			this.y += dy;
		}
		@Override public String toString() {
			return "x: " + this.x + " y: " + this.y;
		}
	

}
