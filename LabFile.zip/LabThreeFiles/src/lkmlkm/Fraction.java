package lkmlkm;



public class Fraction {
	public int numerator;
	public int denominator;
	
	Fraction() {
		numerator = 0;
		denominator = 0;
	}
	Fraction(int n, int d) {
		numerator = n;
		denominator = d;
	}
	public Fraction(Fraction other){
		this.numerator = other.numerator;
		this.denominator = other.denominator;
		
	}
	public Fraction add(Fraction other){
		int comd = denominator*other.denominator;
	    int answer = (numerator*other.denominator)+(other.numerator*denominator);
	    Fraction n = new Fraction();
	    n.setDenominator(comd);
	    n.setNumerator(answer);
	    return n;
	}
	//This method's role is to check if two "FractionVTwo" objects are similar, and to return a boolean after checking
	public boolean equals(Object other) {
		if( other != null && ! (other instanceof Fraction ) ) {
			return false;
		}
		 Fraction that = (Fraction) other;
		if ((this.numerator == that.numerator) && (this.denominator == that.denominator)) {
			return true;
		}
		return false;
	}
	@Override public String toString() {
		return numerator + "\\" + denominator ;
	}
	public int getNumerator() {
		return numerator;
	}
	public void setNumerator(int n) {
		numerator = n;
	}
	public int getDenominator() {
		return denominator;
	}
	public void setDenominator(int d) {
		 denominator = d;
	}
}
