package lkmlkm;


public class LineSegment {
	public PointTwoD startPoint;
	public PointTwoD endPoint;
	
	public static void main (String[] args) {
		
	}
	public LineSegment() {
		startPoint.setXAndY(0,0);
	}
	public PointTwoD getStartPoint() {
		return startPoint;
	}
	
	public void setStartPoint(PointTwoD start) {
		this.startPoint = start;
	}
	public PointTwoD getEndPoint() {
		return startPoint;
	}
	
	public void setEndPoint(PointTwoD end) {
		this.endPoint = end;
	}
	@Override public String toString () {
		return startPoint + " " + startPoint;
	}
	public boolean equals(Object other) {
		if(other == null || !(other instanceof LineSegment)) { 
			return false; 
		}
		return true;
	}
}
