package labFiles;

public class dv {
	private static int speed = 30;
	   public dv(int speed) {
	       speed = speed;
	   } 
	   public static int getSpeed (){return speed;}
	   public static void main(String[] args) {
	     dv myCar = new dv(60);
	      System.out.println(dv.getSpeed());
	    }
}

