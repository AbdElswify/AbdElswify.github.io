package labFiles;
import java.util.Random;

import Reservation;

public abstract class ReservableItem {
	public boolean[] timeSlots = new boolean[10];
	public String ID = "";
	
	
	public String getId() { 
		return ID; 
    }
	
	public void setId(String i) { 
		System.out.println(i);
		ID = i; 
    }
	
	public boolean isAvailable(int t) { 
		if (timeSlots[t] == false) {
			return true;
		}
		return false;
	} 
	public void reserveTime(int t) {
		timeSlots[t] = true;
	} 
	public int getScore(Reservation res)  {
		Random r = new Random();
		int low = 1;
		int high = 100;
		return r.nextInt(high-low) + low;
	}
	
	 public boolean[] getReservations() {
	        return timeSlots;
	 }

}
