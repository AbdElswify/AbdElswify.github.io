package labFiles;
/*
 * Abd Elswify
 * 
 * Class definition: This class's purpose is simply to call the ObjectList 
 * class's main method where all of the testing for the FractionV2 project 
 * occurs
 */
public class FractionVTwoDriver {

	public static void main(String[] args) {
		ObjectList start = new ObjectList();
		start.main(args);

	}

}
