package labFiles;
import java.util.Random;

import Reservation;

public class CafeReservation extends Reservation{
	CafeReservation (String name, int timeSlot, int numSeatsNeeded) {
		super(name,timeSlot);
		setResourceId(numSeatsNeeded + "");
	}

	public int getScore(Reservation res) {
		Random r = new Random();
		int low = 1;
		int high = 100;
		return r.nextInt(high-low) + low;
	}
}
