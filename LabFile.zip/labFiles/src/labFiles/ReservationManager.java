package labFiles;
import java.util.ArrayList;

public class ReservationManager {
	
	ArrayList<ReservableItem> item = new ArrayList<ReservableItem>();
	ArrayList<Reservation> reserve = new ArrayList<Reservation>();
	
	public void addReservable(ReservableItem items)  {
		item.add(items);
	}
	
	public Reservation makeReservation(Reservation trialRes)  {
		 ReservableItem bestChoice = null; // no best choice by default
		  for (int i = 0; i < item.size(); i++) {
		    ReservableItem thisChoice = item.get(i);
		    if (thisChoice.isAvailable(trialRes.getTime())) { 
		      //if (thisChoice.getScore(trialRes) > 0 && thisChoice.getScore(trialRes) > bestChoice.getScore(trialRes)) {
		        bestChoice = thisChoice; 
		      //}
		    }
		  }

		  if (bestChoice != null) {
		    bestChoice.reserveTime(trialRes.getTime()); // or something like that
		    trialRes.setResourceId(bestChoice.getId()); // or something like that
		    reserve.add(trialRes); // add our reservation the the manager's list
		  } else {
		    System.out.println("Couldn't reserve item"); 
		    return null;
		  }
		return trialRes;
	}
	public void sortReservations()   {
		for (int i = 0; i < reserve.size(); i++) {
            boolean canExit = true;
            for (int j = 0; j < reserve.size() - 1; j++) {
                if (reserve.get(j).compareTo(reserve.get(j + 1)) > 0) { // Out of place element
                    Reservation r = reserve.remove(j + 1);
                    reserve.add(j, r); // swap
                    canExit = false; // mark as not done
                }
            }
            if (canExit) break;
        }
	        
	}
	public String toString() {
		 return reserve.toString();
	}

}
