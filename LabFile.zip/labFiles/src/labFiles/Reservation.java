package labFiles;
import java.util.Random;

public abstract class Reservation implements Comparable{
	public String nme;
	public int tme;
	public String ID;
 
	 
	
	Reservation (String customerName, int timeslot) {
		nme = customerName;
		tme = timeslot;
	}
 
	public String getCustomer() {
		return nme;
	}
	public int getTime()  {
		return tme;
	}
	@Override
	public String toString() {
		return "Reservation customer: " + nme + " - " + "timeSlot: " + tme + " - " + "Resource ID: " + ID  + "\n";
	}
	public void setResourceId(String id)  {
		 ID = id;
	}
	@Override
	public int compareTo(Object o) {
		if (o instanceof Reservation) {
			  Reservation other = (Reservation) o;
			  return nme.compareTo(other.nme);
			}
		return 0;
	}
	abstract int getScore(Reservation res);
}
