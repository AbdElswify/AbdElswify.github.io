package labFiles;
import java.util.ArrayList;
import java.util.Random;

import Reservation;

public class BoatReservations extends Reservation {
	public boolean check = true;
	
	BoatReservations(String customerName, int timeSlot) {
		 super(customerName, timeSlot);
	}
	
	public void addBoatPreference(String boatName) {
		//System.out.println(check);
		if (check == true) {
			//System.out.println(boatName);
			check = false;
			setResourceId(boatName);
			//System.out.println(check);
		}
	}

	
 
	public int getScore(Reservation res)  {
		Random r = new Random();
		int low = 1;
		int high = 100;
		return r.nextInt(high-low) + low;
	}

}
