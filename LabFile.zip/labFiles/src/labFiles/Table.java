package labFiles;
import java.util.Scanner;

public class Table extends ReservableItem {
    public int numSeats;
 
	
	Table (Scanner inFile) {
		super.setId(inFile.next());
		numSeats = inFile.nextInt();
	}
	public int getNumSeats() {
		 return numSeats;
	}
	
	
	

}
