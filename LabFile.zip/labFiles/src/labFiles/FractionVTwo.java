package labFiles;
/*
 *Abd Elswify
 *
 *Class Definition: This class's responsibility was to act as an object that could
 *store both the numerator and the denominator of whatever "FractionVTwo" object may
 *be created in the ObjectList class;
 */
public class FractionVTwo {
	public int numerator;
	public int denominator;
	
	FractionVTwo() {
		numerator = 0;
		denominator = 0;
	}
	FractionVTwo(int n, int d) {
		numerator = n;
		denominator = d;
	}
	//This method's role is to check if two "FractionVTwo" objects are similar, and to return a boolean after checking
	public boolean equals(FractionVTwo other) {
		if ((this.numerator == other.numerator) && (this.denominator == other.denominator)) {
			return true;
		}
		return false;
	}
	@Override public String toString() {
		return numerator + "\\" + denominator ;
	}
	public int getNumerator() {
		return numerator;
	}
	public void setNumerator(int n) {
		numerator = n;
	}
	public int getDenominator() {
		return denominator;
	}
	public void setDenominator(int d) {
		 denominator = d;
	}
	
}
