package labFiles;
/*
 * Abd Elswify
 * 
 * Class definition: This class serves to mainly enable the possible 
 * reduction of the numerator and denominator within the "FractionVTwo"
 * class among other things.
 */
public class FractionCounter {
	FractionVTwo Fraction = new FractionVTwo();
	public int counter;
	
	FractionCounter(FractionVTwo theFraction) {
		Fraction = theFraction;
	}
	public boolean compareAndIncrement(FractionVTwo newFraction) {
		if ((Fraction.numerator == newFraction.numerator) && (Fraction.denominator == newFraction.denominator)) {
			counter++;
			return true;
		}
		return false;
	}
	@Override public String toString() {
		return Fraction.numerator + "/" + Fraction.denominator + "has a count of " + counter;
	}
	/*
	 * Method definition: This Method's responsibility is to find the 
	 * greatest common denominator if there is one in the pertaining
	 * fraction and to reduce it accordingly
	 */
	public FractionVTwo reduceTheFraction(FractionVTwo newFraction) {
		 int d;  
		 d = gcd(newFraction.getNumerator(), newFraction.getDenominator());  
		 int x = newFraction.getNumerator() / d;  
		 int y = newFraction.getDenominator() / d;  
		 newFraction.setNumerator(x);
		 newFraction.setDenominator(y);
		 return newFraction;
	}
	/*
	 * Method definition: Its role was to return the greatest common 
	 * denominator after being given the numerator and denominator
	 */
	public int gcd(int a, int b)  
	{  
	    if (b == 0)  
	        return a;  
	    return gcd(b, a % b);       
	}
}
