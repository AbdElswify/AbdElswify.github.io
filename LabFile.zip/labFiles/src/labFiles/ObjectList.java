package labFiles;

import java.io.*;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * Abd Elswify
 * 
 * Class definition: This class serves as the real driverTest/ObjectList 
 * class. It is here that most of the testing is carried out, which includes 
 * negative, zero, and large number fractions in my modified version of
 * "Fraction.txt".
 */
public class ObjectList {
	public Object[] arrayOfFractions;//separate to calculate length
	public int numElements = 0;
	public int length = 0;
	
	public void main(String[] args) { 	    
	    Scanner input = null;
		try {
			input = new Scanner(new FileInputStream("fractions.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("I apologize but it would seem that the file cannot be found");
		}
		
		//This block of code takes the expressions from the text file "fractions" and places them into array "arr", after which it is sent to method "printCount" 
		String cul = "";
		while(input.hasNextLine()) {  
			cul += input.nextLine() + " ";
		}
		
		String[] arr = cul.split(" ");
		length = arr.length;
		arrayOfFractions = new Object[arr.length];
		
		for (int i = 0; i < arr.length; i++) { 	
		     FractionVTwo Fraction = new FractionVTwo();
		     ObjectList Frac = new ObjectList();
			 String[] parts = arr[i].split("/");
			 //After obtaining the numerator and denominator of a fraction from the text class, they are turned into a "FractionVTwo" object and added to the ObjectList array "arrayOfFractions"
		     Fraction.setNumerator(Integer.parseInt(parts[0]));
		     Fraction.setDenominator(Integer.parseInt(parts[1]));
		     FractionCounter F = new FractionCounter(Fraction);
		     FractionVTwo reducedFraction = F.reduceTheFraction(Fraction);
		     Frac.add(reducedFraction, i);   
	    }
		printCount();
	 }

	public void add(FractionVTwo n, int i) {
		arrayOfFractions[i] = n;
	}
	
	/*
	 * Method definition: This method serves to print out all the unique fractions as well as their counts. It also
	 * prints out the number of invalid cases that has occured.
	 */
	public void printCount() {
		//This array/ for loop act as a checking array to ensure that no repeating unique fractions are printed
		FractionVTwo[] provenVal = new FractionVTwo[length];
		for (int i = 0; i < length; i++) { 
			int x = (int) Math.random() * 100;
			int y = (int) Math.random() * 100;
			FractionVTwo pV = new FractionVTwo(x, y);
			provenVal[i] = pV;
		}
		//This for loop prints out the unique fractions after calculating its count while making sure that it doesn't violate any conditions (invalid or already printed)
		int overAllCountOfInvalid = 0;
		for (int i = 0; i < length; i++) { 
	    	 int count = 0;
	    	 for (int x = 0; x < length; x++) {
	    		 if ((((FractionVTwo) arrayOfFractions[x]).getNumerator() == ((FractionVTwo) arrayOfFractions[i]).getNumerator()) && 
	    			(((FractionVTwo) arrayOfFractions[x]).getDenominator() == ((FractionVTwo) arrayOfFractions[i]).getDenominator())) {
	    			 count++;
	    		 }
	    	 }
	    	 //This for loop check whether the unique fraction has already been printed
	    	 boolean check = true;
	    	 for (int x = 0; x < length; x++) {
	    		 if ((provenVal[x].getNumerator() == ((FractionVTwo) arrayOfFractions[i]).getNumerator()) && 
	    			(provenVal[x].getDenominator() == ((FractionVTwo) arrayOfFractions[i]).getDenominator()) || 
	    			((((FractionVTwo) arrayOfFractions[i]).getNumerator() <= 0) || ((FractionVTwo) arrayOfFractions[i]).getDenominator() <= 0)) {
	    			 check = false;
	    		 }	    		  
	    	 }
	    	 //This if statement checks if the unique fraction is invalid
	    	 if (((((FractionVTwo) arrayOfFractions[i]).getNumerator() <= 0)) || (((FractionVTwo) arrayOfFractions[i]).getDenominator() <= 0)) {
				 overAllCountOfInvalid++;
			 }
	    	 
	    	 if (check == true) {
	    		 System.out.println((((FractionVTwo) arrayOfFractions[i]).getNumerator()) + "/" + (((FractionVTwo) arrayOfFractions[i]).getDenominator()) + " has a count of " + count);
	    	 }
	    	 provenVal[i] = (FractionVTwo) arrayOfFractions[i];	 
	    }     
		System.out.println("Number of invalid fractions (zero and negative) are: " + overAllCountOfInvalid);
	}
}
