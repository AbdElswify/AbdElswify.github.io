package labFiles;
import java.util.Scanner;

import ReservableItem;

public class Boat extends ReservableItem{
	public String id;
 
	
	public Boat(Scanner scanner) {
			super.setId(scanner.nextLine());	
	}
}
