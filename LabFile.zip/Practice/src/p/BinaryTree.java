 public boolean isEmpty() {
     for (int i = 0; i < arraySize; i++) {
    	 if (array[i].data != null ) {
    		 return false
    	 }
     }
     return true;
  }
  public int count() {
     return arraySize;
  }
