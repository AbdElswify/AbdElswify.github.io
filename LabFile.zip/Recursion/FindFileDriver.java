
public class FindFileDriver {
	/*
	 * Name: Abd Elswify
	 * 
	 * Class Defenition: This class's purpose is to test FindFile's methods
	 * for cases that occur once, twice/Max_Number, or none at all
	 */
	public static void main(String[] args) {
		
		String targetFile = "output_log.txt";
		String pathToSearch = "C:\\Users\\abdel\\Downloads\\RCTN\\RCTN_Data";
		FindFile finder = new FindFile(100);
		finder.directorySearch(targetFile, pathToSearch);
		System.out.println(finder.toString());
		
		String targetFile2 = "Animal.java";
		String pathToSearch2 = "C:\\Users\\abdel\\Downloads\\FlyingObject.zip\\FlyingObject";
		FindFile finder2 = new FindFile(10);
		finder2.directorySearch(targetFile2, pathToSearch2);
		System.out.println(finder2.toString());
		
		String targetFile3 = "ccc.zip";
		String pathToSearch3 = "C:\\Users\\abdel\\Downloads\\FD";
		FindFile finder3 = new FindFile(2);
		finder3.directorySearch(targetFile3, pathToSearch3);
		System.out.println(finder3.toString());
	}

}
