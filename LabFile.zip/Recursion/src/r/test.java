package r;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 writeSquares(5);
		 System.out.println();
		 writeSquares(1);
		 System.out.println();
		 writeSquares(8);
		 System.out.println();
	}
	public static void writeSquares(int n){
		if (n == 1){
			System.out.println(n);
			return;
		}
		if (n%2 == 1) 
			System.out.println(n*n);
			
		writeSquares(n-1);
		
		if (n%2 == 0) {
			System.out.println(n*n);
		}
	}

}
