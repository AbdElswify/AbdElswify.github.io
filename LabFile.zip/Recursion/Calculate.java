
public class Calculate {
	public static void main(String[] args) {
		System.out.println(sumTo(7));
	}
	
	public static double sumTo(int n) {
		double nx = n;
		if (n == 1) {
			return 1.0;
		} else {
			return (1/nx) + sumTo(n-1);
		}
	}
}
