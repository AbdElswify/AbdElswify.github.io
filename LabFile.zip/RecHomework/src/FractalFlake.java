import java.awt.*;

public class FractalFlake extends Shape {

    private int limit;
    private int branches;

    public FractalFlake(int limit, int branches, int x, int y){
        super(x,y);
        if(limit >= 1 || limit <= 50){
            this.limit = limit;
        }
        else
            this.limit = 1;
        if(branches >= 5 || branches <= 12){
            this.branches = branches;
        }
        else
            this.branches = 5;
    }

    @Override
    public void draw(Graphics g){
    }
}
