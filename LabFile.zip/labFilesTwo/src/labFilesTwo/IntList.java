package labFilesTwo;

public class IntList {
	private int[] data = new int[100];
	private int numElements = 0;
	
	public static void main(String[] args) { 
	    IntList a = new IntList();
	    a.add(95); a.add(100); a.add(58);
	    System.out.println(a.toString() );
	    System.out.println(a.sum() );
	    System.out.println(a.indexOf(100)); //uncomment these to work on next
	    System.out.println(a.indexOf(20));
	  
	}
	
	public void add(int n) {
		data[numElements] = n;
		numElements++;
	}
	@Override public String toString() {
		String retVal="";
		for (int x : data) {
			retVal += x + " , ";
		}
		return retVal;
	}
	public int sum() {
		int sum = 0;
		for (int x : data) {
			sum += x;
		}
		return sum;
	}
	public int indexOf(int target) {
		for (int x : data) {
			if (x == target) {
				return 1;
			}
		}
		return -1;
	}
}
