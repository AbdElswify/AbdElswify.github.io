package labFilesTwo;

public class Circle {
	private int x;
	private int y;
	private double radius;
	private String shape = "O";
	
	public Circle() {
		x = 0;
		y = 0;
	}
	public Circle(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public Circle(int x, int y, double sl) {
		this.x = x;
		this.y = y;
		radius = sl;
	}
	public void draw() {
		System.out.println("Chosen Shape: " + shape);
	}
	public int getX() {
		return this.x;
	}
	public int getY() {
		return this.y;
	}
	public double getRadius() {
		return radius;
	}
	public double getArea() {
		return (radius * radius) * 3.1415;
	}
	void setX(int nX) { //changes x to nX
		this.x = nX;
	}
	void setY(int nY) { //changes y to nY
		this.y = nY;
	}
	void setRadius(int sl) { //change sidelength�s value to sl
		radius = sl;
	}
	@Override public String toString() {
		return shape;
	}
	public boolean equals(Circle that) {
		if ((this.x == that.x) && (this.y == that.y) && (this.radius == that.radius) ) {
			return true;
		}
		return false;
	}
}
