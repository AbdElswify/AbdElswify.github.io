package labFilesTwo;

public class Date {
	public int month;
	public int year;
	public int day;
	
	public void main(String[] args) {
		setDate(12, 12, 2000);
		System.out.println(month + " " + day + " " + year);
    }
	public void setDate(int m, int d, int y) {
		this.month = m;
		this.day = d;
		this.year = y;
	}
}
