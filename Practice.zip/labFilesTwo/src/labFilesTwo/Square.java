package labFilesTwo;

public class Square {
	private int x;
	private int y;
	private double sideLength;
	private String shape = "[]";
	
	public Square() {
		x = 0;
		y = 0;
	}
	public Square(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public Square(int x, int y, double sl) {
		this.x = x;
		this.y = y;
		sideLength = sl;
	}
	public void draw() {
		System.out.println("Chosen Shape: " + shape);
	}
	public int getX() {
		return this.x;
	}
	public int getY() {
		return this.y;
	}
	public double getSideLength() {
		return sideLength;
	}
	public double getArea() {
		return x * y;
	}
	void setX(int nX) { //changes x to nX
		this.x = nX;
	}
	void setY(int nY) { //changes y to nY
		this.y = nY;
	}
	void setSideLength(int sl) { //change sidelength�s value to sl
		sideLength = sl;
	}
	@Override public String toString() {
		return shape;
	}
	public boolean equals(Square that) {
		if ((this.x == that.x) && (this.y == that.y) && (this.sideLength == that.sideLength) ) {
			return true;
		}
		return false;
	}
}
