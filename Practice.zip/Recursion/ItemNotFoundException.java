
/*
 * Name: Abd Elswify
 * 
 * Class Defenition: This class's purpose is to catch any exception, and 
 * in so showing the user that the intended word that they were looking for 
 * is not in the array
 */
public class ItemNotFoundException extends RuntimeException {

    public ItemNotFoundException() {
    	super( "Target was not found..... unfortunate :(");
    }

    public ItemNotFoundException(String message) {
        super(message);
    }
    

}