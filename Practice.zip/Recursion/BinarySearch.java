
/*
 * Name: Abd Elswify
 * 
 * Class Defenition: This class's purpose is to both recursively and 
 * iteratively find the intended word within a sorted String array using
 * the concept of BinarySearch
 */
public class BinarySearch extends SearchAlgorithm{
	//This method utilizes iteration and BinarySearch in order to find the intended word
	@Override
	public int search(String[] A, String x) throws ItemNotFoundException {
		int left = 0,
		right = A.length - 1;
		while (left <= right)
		{
			int mid = (left + right) / 2;
			if (x.equals(A[mid])) {
				 super.incrementCount();
				return mid;
			}
			else if (x.compareTo(A[mid]) < 0) {
				super.incrementCount();
				right = mid - 1;
			}
			else {
			    super.incrementCount();
				left = mid + 1;
			}
		}
		 throw new ItemNotFoundException();
	}
	//This method utilizes recursion and BinarySearch in order to find the intended word
	@Override
	public int recSearch(String[] A, String x, int l, int r) throws ItemNotFoundException {
		if (r >= l) {
			 super.incrementCount();
            int mid = l + (r - l) / 2; 
            if (x.equals(A[mid])) {
            	super.incrementCount();
                return mid; 
            }
            if (x.compareTo(A[mid]) < 0) {
            	super.incrementCount();
                return recSearch(A, x, l, mid - 1); 
            }

            return recSearch(A, x, mid + 1, r); 
        }else { 
        	super.incrementCount();
        	throw new ItemNotFoundException();		 
        }	 
	}
}
