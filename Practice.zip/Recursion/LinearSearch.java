/*
 * Name: Abd Elswify
 * 
 * Class Defenition: This class's purpose is to both recursively and 
 * iteratively find the intended word within a sorted String array using
 * the concept of LinearSearch
 */
public class LinearSearch extends SearchAlgorithm{
	
	//This method utilizes iteration and LinearSearch in order to find the intended word
	@Override
	public int search(String[] input, String st) throws ItemNotFoundException {
	     for(int i = 0;i<input.length;i++) {
	         if(input[i].equals(st))
	         {
	        	super.incrementCount();
	            return i;
	         }
	         super.incrementCount();
	     }
	     throw new ItemNotFoundException();
	}
	
	/*
	 * 
	 * Special Method Defenition: This method's intended purpose was to iteratively
	 * go through the String array utilizing recursion and LinearSearch. This however resulted in an
	 * OutOfBounds Exception that prevented the target from being found
	 */
	@Override
	public int recSearch(String[] input, String st, int l, int r) throws ItemNotFoundException {
		if (l > r) {
			 throw new ItemNotFoundException();
		} else if (input[l].compareTo(st) != 0) {
			return recSearch( input, st, l + 1, r);
		} else {
			return l;
		}
	}
}
