module LabFive {
	requires java.desktop;
}