package p;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*Abd Elswify
 * 
 * Class Definition: This class's purpose is to override the super methods of the parent Shape class to make a SupriseShape
 */
public class SurpriseShape extends Shape{
	public int w;
	public int h;

	public SurpriseShape(int a, int b) {
		super(a,b);
	}
	public SurpriseShape(int a, int b, int w, int h) {
		super(a,b);
		this.w = w;
		this.h = h;
	}
	//This method is meant to calculate the area of the pertaining SupriseShape
	@Override public double getArea() {
		return w*h;
	}
	//This method is meant to draw a green rectangle with rounded corners
	@Override public void draw( Graphics g ){
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor( Color.GREEN );
		g2d.fillRoundRect(getX(), getY(), w, h, 30, 30);
	}
	public double getWidth() {
		return w;
	}
	public void setWidth(int r) {
		this.w = r;
	}
	public double getHeight() {
		return h;
	}
	public void setHeight(int r) {
		this.h = r;
	}
}
