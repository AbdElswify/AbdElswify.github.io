package p;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

/*Abd Elswify
 * 
 * Class Definition: This class's purpose is to override the super methods of the parent Shape class to make a Rectangle
 */
public class Rectangle extends Shape{
	public int w;
	public int h;
	public Rectangle(int a, int b) {
		super(a, b);
	}
	public Rectangle(int a, int b, int w, int h) {
		super(a, b);
		this.w = w;
		this.h = h;
	}
	//This method is meant to calculate the area of the pertaining Rectangle shape
	@Override public double getArea() {
		return w*h;
	}
	//This method is meant to draw a black Rectangle followed by a series of outlined rectangles in different colors
	@Override public void draw( Graphics g ){
		Graphics2D g2d = (Graphics2D) g;
		final int x = getX();
		final int y = getY();
		g2d.setColor( Color.black );
		g2d.setPaint( new GradientPaint( x, y, Color.RED, x, y, Color.BLACK, true) );
		g2d.fill3DRect(x, y, w, h, false);
		for(int i = 0; i < 30; i++) {
			if (i%2 ==0) {
				//The random object along with the variables r,z,b are utilized for random access to the Color values
				Random rand = new Random();
			    float r = rand.nextFloat();
			    float z = rand.nextFloat();
			    float b = rand.nextFloat();
			    Color randomColor = new Color(r, z, b);
				g2d.setColor(randomColor);
				g2d.setPaint( new GradientPaint( x, y, Color.black, x, y, Color.BLACK, true) );
				g2d.draw3DRect(super.getX(),super.getY(),w+(5*i),h+(5*i),false);
			} else {
				Random rand = new Random();
			    float r = rand.nextFloat();
			    float z = rand.nextFloat();
			    float b = rand.nextFloat();
			    Color randomColor = new Color(r, z, b);
				g2d.setColor(randomColor);
				g2d.setPaint( new GradientPaint( x, y, Color.RED, x, y, Color.BLACK, true) );
				g2d.draw3DRect(super.getX(),super.getY(),w+(5*i),h+(5*i),false);
			}
		}
		g.draw3DRect(super.getX(),super.getY(),w,h,false);
	}
	public double getWidth() {
		return w;
	}
	public void setWidth(int r) {
		this.w = r;
	}
	public double getHeight() {
		return h;
	}
	public void setHeight(int r) {
		this.h = r;
	}

}
