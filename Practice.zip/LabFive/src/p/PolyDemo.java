package p;
import java.util.*;
import javax.swing.*;
import java.awt.*;

/*Abd Elswify
 * Class PolyDemo (is a JFrame) and PolyDemoPanel (is a JPanel)
 * 
 * Class Defenition: These two classes are meant to set up the paint panel and print out the randomly selected shapes
 */


class PolyDemo extends JFrame {
	
	
	public PolyDemo() {
		getContentPane().add( new PolyDemoPanel() );
		//just some windowing stuff that must happen for all Frames
		setSize( 500,500 );
		setVisible( true );
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	}
	
	
	public static void main( String args[] ) {
		PolyDemo myApp = new PolyDemo();
	}
	
	
	//this is our first "inner" or internal class 
	//the purpose of this class is solely to support the JFrame class above, and I don't want it reused in arbitrary contexts, so by nesting this class here
	//I can indicate the intent a bit more clearly that this class "goes with" the class above it
	//In general, each class is a separate entity that should be contained in a separate file
	public class PolyDemoPanel extends JPanel {		
		//Instead of 20 shapes on one screen, only one will be printed
		Shape[] myShapes= new Shape[1];
		public PolyDemoPanel() {

			/*********************************************************************************************************************
			* Code for populating our myShapes changes minimally when new classes are introduced (only in getRandShape())
			*********************************************************************************************************************/
			for( int i = 0; i < myShapes.length; i++ ) {
				myShapes[i] =  getRandShape();
			}
		}
		
		/*********************************************************************************************************************
		 * Code for drawing our shapes doesn't change at all! Since we intended to take advantage of polymorphism, we coded 
		 * this "in general" with respect to the superclass, and not specific to any subclass.
		 *********************************************************************************************************************/
		public void paint( Graphics g ) {
			super.paint(g);  //don't remove - required for GUI widgets to draw correctly
			/************************
			 * Late Binding Demo
			 ************************/
			for( int i = 0; i < myShapes.length; i++ ){
				//which draw method is invoked here? There are many forms of the method (polymorphic), so which is chosen?
				//Java has RTTI about every object, and it uses this info to choose the correct method to invoke!
				myShapes[i].draw(g);	
			}	
		}
			
		//This method enables the completely random generation of unique coordinates between 0 and 200
		public int getRandInt() {
			return ( (int) ( Math.random() * 200 ) );	
		}
		
		//This method is specialized for the Shape Triangle in order to obtain a set of y and x points
		public int[] getRandIntArr() {
			int[] arr = new int[3];
			for(int i = 0; i < arr.length; i++) {
				arr[i] = (int) ( Math.random() * 350 );
			}
			return arr;
		}
		
		//This method's role is to determine which Shape to return for printing
		public Shape getRandShape() {
			Shape retVal = null;
			final int x = getRandInt();
			final int y = getRandInt();
			//Using a random generator, this switch case decides what type of Shape to set retVal to
			switch( ( int )(Math.random() * 4) ) {
				case 0: 	retVal = new Rectangle( x, y, getRandInt(), getRandInt() );
							break;
				case 1: 	retVal = new Triangle( getRandIntArr(), getRandIntArr());
							break;
				case 2: 	retVal = new SurpriseShape(x,y,getRandInt(),getRandInt());
							break;
				case 3: 	retVal= new Circle( x,y,getRandInt());
							break;				
			}
		
			return retVal;
		}
	}	
	
}

 









