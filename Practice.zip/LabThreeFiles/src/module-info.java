module LabThreeFiles {
	requires java.desktop;
}