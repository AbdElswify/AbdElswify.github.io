package lkmlkm;

public class Math1 {
	public final static double PI = 3.141592653589;
	public final static double E = 10;
	public int max(int a, int b) {
		return Math.max(a, b);
	}
	public double max(double a, double b) {
		return Math.max(a, b);
	}
	public int pow(int base, int exp) {
		return (int) Math.pow(base, exp);
	}
}

/**
 * Final Section:
 * 
 * a. Enables the prevention of a privacy leak from occuring
 * b.No it doesn't
 * c. I'd say that the scope of the variable is local to that method
 * 
**/
