package lkmlkm;

public class Date {
	public int month;
	public int year;
	public int day;
	
	public void main(String[] args) {
		Date newDate = new Date(12, 12, 2000);
		System.out.println(newDate.toString());
		 
    }
	public Date(int m, int d, int y) {
		assert (((m >= 1) && (m <= 12)) && ((d >= 1) && (d <= 31)) && (y > 0));
		this.month = m;
		this.day = d;
		this.year = y;
	}
	public Date() {
		this.month = 0;
		this.day = 0;
		this.year = 0;
	}
	public Date(Date Other) {
		assert (((Other.month >= 1) && (Other.month <= 12)) && ((Other.day >= 1) && (Other.day <= 31)) && (Other.year > 0));
		this.month = Other.month;
		this.day = Other.day;
		this.year = Other.year;
	}
	public int getMonth() {
		return this.month;
	}
	public int getDay() {
		return this.day;
	}
	public int getYear() {
		return this.year;
	}
	public void setMonth(int nX) { 
		this.month = nX;
	}
	public void setDay(int nY) { 
		this.day = nY;
	}
	public void setYear(int nX) { 
		this.year = nX;
	}
	
	@Override public String toString() {
		return this.month + " " + this.day + " " + this.year;
	}
	public boolean equals(Object r) {
		Date newDate = (Date) r;
		if ((this.month == newDate.getMonth()) && (this.day == newDate.getDay()) && (this.year == newDate.getYear())) {
			return true;
		}
		return false;
	}
	
}
 