package lkmlkm;
import java.awt.*;
public class Shape {
	private int x;
	private int y;
	private Color obj;
	
	public Shape() {
		this.x = 0;
		this.y  = 0;
		this.obj = new Color(0, 0, 0);
	}
	public Shape(int x, int y, Color color) {
		this.x = x;
		this.y = y;
		this.obj = color;
	}
	public Shape(Shape other) {
		this.x = other.x;
		this.y = other.y;
		this.obj = other.obj;
	}
	@Override public String toString() {
		return x + " " + y + " " + obj.toString();
	}
	public double getArea() {
		return x*y;
	}
	public void draw(Graphics g) {
		
	}
}
