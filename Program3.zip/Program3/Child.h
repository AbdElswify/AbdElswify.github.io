#ifndef CHILD_H_
#define CHILD_H_
#include <iostream>
using namespace std;

/*
This header's purpose is to act as an interface for Child.cpp
*/

class Child {
friend ostream& operator<<(ostream& out_stream, const Child& other); //Child operator overload for cin
friend istream& operator>>(istream& in_stream, Child& other); //Child operator overload for cout
public:
	//constructer
	Child();
	Child(string fn, string ln, int a);

	//destructor
	~Child();

	void setChild(string fn, string ln, int a); //acts as a setter for the Child class by changing the fn, ln, a
	
	//operator overloads for the Child class
	void operator=(const Child& other);
	bool operator>(const Child& rhs) const;
	bool operator<(const Child& rhs) const;
	bool operator>=(const Child& rhs) const;
	bool operator<=(const Child& rhs) const;
	bool operator==(const Child& other);
	bool operator!=(const Child& other);


private:
	//
	string firstname_;
	string lastname_;
	int age_;
};

#endif 