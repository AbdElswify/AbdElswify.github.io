#ifndef CHILD_CPP_
#define CHILD_CPP_
#include <iostream>
#include "child.h"
#include <string>
using namespace std;

/*
This class's purpose is to create a functional object class containing the necassary overloaded operators so that it can be used for the "List342" class
*/


Child::Child() {
	firstname_ = "";
	lastname_ = "";
	age_ = 0;
}

Child::Child(string fn, string ln, int a) {
	firstname_ = fn;
	lastname_ = ln;
	age_ = a;
}


Child::~Child() {

}


void Child::setChild(string fn, string ln, int a) {
	firstname_ = fn;
	lastname_ = ln;
	age_ = a;
}

//operations
void Child::operator=(const Child& other) {
	firstname_ = other.firstname_;
	lastname_ = other.lastname_;
	age_ = other.age_;
}

bool Child::operator<(const Child& rhs) const {
    if (lastname_ < rhs.lastname_) {
        return true;
    }
    if (firstname_ < rhs.firstname_ && lastname_ == rhs.lastname_) {
        return true;
    }
    if (age_ < rhs.age_ && lastname_ == rhs.lastname_ && firstname_ == rhs.firstname_) {
        return true;
    }
    return false;
}

bool Child::operator<=(const Child& rhs) const {
    if (lastname_ <= rhs.lastname_) {
        return true;
    }
    if (firstname_ <= rhs.firstname_ && lastname_ == rhs.lastname_) {
        return true;
    }
    if (age_ <= rhs.age_ && lastname_ == rhs.lastname_ && firstname_ == rhs.firstname_) {
        return true;
    }
    return false;
}

bool Child::operator>(const Child& rhs)const {
    return !(*this <= rhs);
}


bool Child::operator>=(const Child& rhs) const {
    return !(*this < rhs);
}

ostream& operator<<(ostream& out_stream, const Child& other) {
	out_stream << other.firstname_ << other.lastname_ << other.age_;
	return out_stream;
}

istream& operator>>(istream& in_stream, Child& other) {
	in_stream >> other.firstname_ >> other.lastname_ >> other.age_;
	return in_stream;
}



bool Child::operator==(const Child& other) {
	if ((other.firstname_ == firstname_) && (other.lastname_ == lastname_) && (other.age_ == age_)) {
		return true;
	}
	return false;
}


bool Child::operator!=(const Child& other) {
	return !(*this == other);
}

#endif 