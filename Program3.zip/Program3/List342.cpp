/*
This class's purpose is to create a templatized sorted linked list of nodes that can execute various actions
*/

/*
template <typename ItemType>
List342<ItemType>::~List342() {
	this->DeleteList();
}

template <typename ItemType>
List342<ItemType>::List342() {
	head_ = nullptr;
}

template <typename ItemType>
List342<ItemType>::List342(const List342& aList) {
	head_ = nullptr;
	*this = aList;
}

template <typename ItemType>
bool List342<ItemType>::BuildList(string fileName) {
	ifstream in_file;
	in_file.open(fileName);
	if (in_file.is_open()) {
		while (!in_file.eof()) {
			ItemType item;
			in_file >> item;
			Insert(new ItemType(item));
		}
		return true;
	}
	cout << "file: " << fileName << " not found";
	return false;

}

template <typename ItemType>
bool List342<ItemType>::Insert(ItemType* obj) {
	Node<ItemType>* insNode = new Node<ItemType>;
	insNode->data_ = obj;
	if (isEmpty() || *insNode->data_ < *head_->data_) {
		insNode->next_ = head_;
		head_ = insNode;
	}
	else {
		ItemType* o = new ItemType;
		if (Peek(*obj, *o)) {
			return false;
		}
		Node<ItemType>* current = head_->next_;
		Node<ItemType>* previous = head_;
		while (current != NULL && *current->data_ < *insNode->data_) {
			previous = current;
			current = current->next_;
		}
		insNode->next_ = current;
		previous->next_ = insNode;
	}
	return true;
}

template <typename ItemType>
bool List342<ItemType>::Remove(ItemType val, ItemType& result) {
	Node<ItemType>* pTemp;
	if (head_ == nullptr) {
		return false;
	}
	if (head_->data_ == &val) {
		result = *head_->data_;
		Pop(*head_->data_);
		return true;
	}
	Node<ItemType>* pNode = head_;
	while (pNode->next_ != nullptr) {
		if (*pNode->next_->data_ == val) {
			result = *pNode->next_->data_;
			pTemp = pNode->next_;
			pNode->next_ = pNode->next_->next_;
			delete pTemp;
			return true;
		}
		pNode = pNode->next_;
	}

	return false;

}

template <class ItemType>
bool List342<ItemType>::Peek(ItemType target, ItemType& result) const {
	if (head_ == nullptr) {
		return false;
	}

	if (head_->data_ == &target) {
		result = *head_->data_;
		return true;
	}

	Node<ItemType>* pNode = head_;
	while (pNode->next_ != nullptr) {
		if (*pNode->data_ == target) {
			result = *pNode->next_->data_;
			pNode = pNode->next_->next_;
			return true;
		}
		pNode = pNode->next_;
	}

	return false;
}

template <typename ItemType>
bool List342<ItemType>::isEmpty() const {
	if (head_ == nullptr) {
		return true;
	}
	return false;
}

template <typename ItemType>
void List342<ItemType>::DeleteList() {
	ItemType a;
	while (Pop(a));
}

template <typename ItemType>
bool List342<ItemType>::Merge(List342& list1) {
	if (list1.isEmpty()) {
		return false;
	}
	if (list1 == *this) {
		return false;
	}


	*this += list1;
	list1.DeleteList();


	return true;
}

template <typename ItemType>
bool List342<ItemType>::Pop(ItemType& val) {
	if (head_ == NULL) {
		return false;
	}
	else {
		Node<ItemType>* temp;
		temp = head_;
		val = *temp->data_;
		head_ = head_->next_;
		delete temp;
		return true;
	}
}
template <typename ItemType>
List342<ItemType>& List342<ItemType>::operator+(const List342& other) {

	List342<ItemType> result = *this;
	result = result + other;
	return result;
}

template <typename ItemType>
List342<ItemType>& List342<ItemType>::operator+=(const List342& other) {
	Node<ItemType>* curr2 = other.head_;
	while (curr2 != nullptr) {
		Insert(curr2->data_);
		curr2 = curr2->next_;
	}
	return *this;
}


template <typename ItemType>
bool List342<ItemType>::operator==(const List342& rhs) {

	Node<ItemType>* curr1 = head_;
	Node<ItemType>* curr2 = rhs.head_;
	if (curr1 == nullptr && curr2 == nullptr) {
		return true;
	}

	while (curr1 != nullptr && curr2 != nullptr) {
		if (curr1->data_ != curr2->data_) {
			return false;
		}
		curr1 = curr1->next_;
		curr2 = curr2->next_;
	}

	return true;
}

template <typename ItemType>
bool List342<ItemType>::operator!=(const List342& other) {
	return !(*this == other);
}

template <typename ItemType>
List342<ItemType>& List342<ItemType>::operator=(const List342& other) {
	if (this == &other) {
		cout << "Same memory address" << endl;
		return *this;
	}

	this->DeleteList();

	Node<ItemType>* pNode = other.head_;

	while (pNode != nullptr) {
		Insert(pNode->data_);
		pNode = pNode->next_;
	}
	return *this;
}
*/