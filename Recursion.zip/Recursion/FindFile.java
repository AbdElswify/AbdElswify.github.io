import java.io.File;
import java.util.ArrayList;
public class FindFile {
	/*
	 * Name: Abd Elswify
	 * 
	 * Class Definition: This class's purpose is to locate a file within a 
	 * directory path while also counting up the number of its occurences
	 */
    private int MAX_NUMBER_OF_FILES_TO_FIND;
    private int matchCount;
    private ArrayList<String> files = new ArrayList<String>();
    public FindFile(int maxFiles){
        MAX_NUMBER_OF_FILES_TO_FIND = maxFiles;
    }

    //This method's role is to recursively locate the file path name, given that there is a String target and a directory name
    public void directorySearch(String target, String dirName){
        File dirNameFile = new File(dirName);
        if(dirNameFile.isDirectory()){
            for(File file : dirNameFile.listFiles()){
                if(file.isDirectory()){
                    directorySearch(target, file.toString());
                } else {
                    if(file.getName().equals(target)){
                        if(matchCount < MAX_NUMBER_OF_FILES_TO_FIND){
                            matchCount++;
                            files.add(file.getAbsoluteFile().toString());
                        }
                    }
                }
            }
        }
        else{
            System.out.println("Error");
            files.add("ERROR");
        }

    }
    public int getCount(){
        return this.matchCount;
    }


    public ArrayList<String> getFiles(){
        return files;
    }
    public String toString() {
		return  "matchCount: " + matchCount + "      files: " + files.toString();
    	
    }
}
