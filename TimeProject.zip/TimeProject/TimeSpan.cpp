#include "TimeSpan.h"
#include <iostream>
#include <cmath>
using namespace std;

TimeSpan::TimeSpan() {
    this->seconds = 0;
    this->minutes = 0;
    this->hours = 0;
}
TimeSpan::TimeSpan(double sec) {
    this->seconds = sec;
    this->minutes = 0;
    this->hours = 0;
}
TimeSpan::TimeSpan(double min, double sec) {
    this->seconds = sec;
    this->minutes = min;
    this->hours = 0;
}
TimeSpan::TimeSpan(double h, double min, double sec) {
    this->seconds = sec;
    this->minutes = min;
    this->hours = h;
}

void TimeSpan::calculateCorrectTime() {
    calculateTotalSeconds();
    hours = (int)(totalSeconds/60/60); 
    minutes = (int)(totalSeconds/60 - hours*60);
    seconds = (int)( totalSeconds - (hours * 60* 60+ minutes * 60));
}

void TimeSpan::calculateTotalSeconds() {
    totalSeconds = (hours*60*60) + (minutes*60) + (seconds);
}




//return the number of hours as an int 
int TimeSpan::getHours() const{
    return this->hours;
}  
//return the number of minutes as an int
int TimeSpan::getMinutes() const{
    return this->minutes;
}  
 //return the number of Seconds as an int
int TimeSpan::getSeconds() const{
    return this->seconds;
} 
//set the number of hours, minutes, seconds and return true if successful.
bool TimeSpan::setTime(double h, double min, double sec){
    this->seconds = sec;
    this->minutes = min;
    this->hours = h;
    calculateCorrectTime();
    return true;
} 

void TimeSpan::Print() {
    calculateCorrectTime();
	cout << "Hours: " << hours << ", Minutes:  " << minutes << ", Seconds: " << seconds << endl;
}

TimeSpan TimeSpan::operator+(const TimeSpan& otherTimeSpan) {
    this->seconds += otherTimeSpan.seconds;
    this->minutes += otherTimeSpan.minutes;
    this->hours += otherTimeSpan.hours;
    return *this;
}
TimeSpan TimeSpan::operator-(const TimeSpan& otherTimeSpan) {
    this->seconds -= otherTimeSpan.seconds;
    this->minutes -= otherTimeSpan.minutes;
    this->hours -= otherTimeSpan.hours;
    return *this;
}
TimeSpan TimeSpan::operator-() {
    this->seconds = -this->seconds;
    this->minutes = -this->minutes;
    this->hours = -this->hours;
    return *this;
}

TimeSpan TimeSpan::operator+=(const TimeSpan& otherTimeSpan) {
    TimeSpan result = *this + otherTimeSpan;
    return result;
}

TimeSpan TimeSpan::operator-=(const TimeSpan& otherTimeSpan){
    TimeSpan result = *this - otherTimeSpan;
    return result;
}

bool TimeSpan::operator==(const TimeSpan& otherTimeSpan){
    if ((this->seconds + (this->minutes*60) + (this->hours*60*60)) == ((otherTimeSpan.seconds + (otherTimeSpan.minutes*60) + (otherTimeSpan.hours*60*60)))) {
        return true;
    } else {
        return false;
    }
}

bool TimeSpan::operator!=(const TimeSpan& otherTimeSpan) {
    if (!(*this == otherTimeSpan)) {
        return true;
    } else {
        return false;
    }
}

//ostream& operator<< (ostream& out_stream, const TimeSpan& rat) {
//    out_stream << "Hours: " << rat.getHours() << ", Minutes:  " << rat.getMinutes() << ", Seconds: " << rat.getSeconds() << endl;
//    return out_stream;
//}
//istream& operator>> (istream& in_stream, const TimeSpan& rat) {
//    in_stream >> rat.
//}










