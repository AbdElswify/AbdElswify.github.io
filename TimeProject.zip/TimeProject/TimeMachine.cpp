// TimeMachine.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "TimeSpan.h"

using namespace std;
//cases change if over 60 or if double(Problem with the case(-60 < x < 60))

int main()
{
    TimeSpan dur1(77.4, 15, 6), dur2(127.86), dur3(8, -23, 0), dur4(0, 0, 0);
    TimeSpan dur5(-3, 73, 2), dur6(7, 35, 120), dur7(1.5,4,-10), dur8;
    //dur7 = dur1 + dur3;
    /*
    cout << dur1 << endl;
    cout << dur2 << endl;
    cout << dur3 << endl;
    cout << dur4 << endl;
    cout << dur5 << endl;
    cout << dur6 << endl;
    cout << dur7 << endl;
    */
    //dur1.Print();
     dur5.Print();
    /*
    dur2.Print();
    dur3.Print();
    dur4.Print();
    dur5.Print();
    dur6.Print();
    dur7.Print();
    

    dur7 += dur3;
    dur3.Print();
    dur7.Print();
    dur7 -= dur3;
    dur3.Print();
    dur7.Print();
    
    
    if (dur3 != dur6) {
        cout << "Durations are different." << endl;
    }
    else {
        cout << "Durations are the same" << endl;
    }
    
    
    
    
    
    
    TimeSpan TimeOne(5);
    TimeSpan TimeTwo(5,10);
    TimeSpan TimeThree(5,10,15);  

    TimeThree.Print();
    TimeSpan add = TimeThree + TimeTwo;
    TimeSpan subtract = TimeOne - TimeThree;
    TimeSpan unaryNeg = -TimeTwo;
    add.Print();
    subtract.Print();
    unaryNeg.Print();
    //cout << TimeTwo.getMinutes() << endl;
    //cout << TimeThree.getHours() << endl;

    //cout << TimeThree;
    */
}