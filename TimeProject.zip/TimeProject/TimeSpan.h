 

class TimeSpan
{
//friend ostream& operator<<(ostream& out_stream, const TimeSpan& rat);
//friend istream& operator>>(istream& in_stream, TimeSpan& rat);
public:
    TimeSpan();
    TimeSpan(double sec);
    TimeSpan(double min, double sec);
    TimeSpan(double h, double min, double sec);

    bool setTime(double h, double min, double sec);
    int getHours() const; //return the number of hours as an int
    int getMinutes() const; //return the number of minutes as an int
    int getSeconds() const; //return the number of Seconds as an int

    void Print();
    TimeSpan operator+(const TimeSpan& otherTimeSpan);
    TimeSpan operator-(const TimeSpan& otherTimeSpan);
    TimeSpan operator+=(const TimeSpan& otherTimeSpan);
    TimeSpan operator-=(const TimeSpan& otherTimeSpan);
    bool operator==(const TimeSpan& otherTimeSpan);
    bool operator!=(const TimeSpan& otherTimeSpan);
    TimeSpan operator-();

    void calculateCorrectTime();
    void calculateTotalSeconds();

private: 
	float hours;
    float minutes;
    float seconds;
    float totalSeconds;
	
};
