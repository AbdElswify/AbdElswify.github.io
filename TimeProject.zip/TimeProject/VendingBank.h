#pragma once
#include <string>
#include <vector>
using namespace std;


class VendingBank
{

public:
	VendingBank();
	VendingBank(int id);
	VendingBank(int id, double cashInCoins);
	int getVendingBankID() const;
	void setVendingBankID(int id) const;
	bool checkSnacksRemaining(int id) const;
	void buySnack(int id, vector<int>& snacksOutOfStock, double& cashInCoins);

private: 
	double cashInCoins;
	int id;
	vector<int> snacksOutOfStock;

};