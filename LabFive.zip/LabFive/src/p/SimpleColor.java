package p;
//TODO: if you use this class because you dont have your
//previous SimpleColor, you must document the code with comments
//and fix the setters so they don't invalidate the [0-255] rule
public class SimpleColor {
	private int r;
	private int g;
	private int b;
	
	
	public int getR() {
		return r;
	}

	public void setR(int r) {
		assert (0 <= r) && (r <= 255): "Value out of bounds";
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		assert (0 <= g) && (g <= 255): "Value out of bounds";
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		assert (0 <= b) && (b <= 255): "Value out of bounds";
		this.b = b;
	}

	public void setColor(int a, int b, int c) {
		assert ((0 <= a) && (a <= 255)) && ((0 <= b) && (b <= 255)) && ((c <= b) && (c <= 255)) : "Value out of bounds";
		setR(a);
		setG(b);
		setB(c);
	}
	public SimpleColor() {}
	
	public SimpleColor(int r, int g, int b) {
		assert ((0 <= r) && (r <= 255)) && ((0 <= g) && (g <= 255)) && ((0 <= b) && (b <= 255)) : "Value out of bounds";
		setR(r);
		setG(g);
		setB(b);
	}
	public SimpleColor(SimpleColor b) {
		this(b.r,b.g,b.b);
	}
}