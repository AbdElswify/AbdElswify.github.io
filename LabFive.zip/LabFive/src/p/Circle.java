package p;

import java.awt.Graphics;

public class Circle extends Shape{
	public double r;
	
	public Circle(int a, int b) {
		super(a, b);
		
	}
	public Circle(int a, int b, double r) {
		super(a, b);
		this.r = r;
	}
	@Override public double getArea() {
		return Math.PI * r * r;
	}
	@Override public void draw( Graphics g ){
		g.drawOval(super.getX(),super.getY(), 5,5);
	}
	public double getRadius() {
		return r;
	}
	public void setRadius(double r) {
		this.r = r;
	}
}
