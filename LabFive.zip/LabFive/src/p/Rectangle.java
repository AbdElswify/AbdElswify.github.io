package p;

import java.awt.Graphics;

public class Rectangle extends Shape{
	public double w;
	public double h;
	public Rectangle(int a, int b) {
		super(a, b);
	}
	public Rectangle(int a, int b, double w, double h) {
		super(a, b);
		this.w = w;
		this.h = h;
	}
	@Override public void draw( Graphics g ){
		g.draw3DRect(super.getX(),super.getY(),10,10,false);
	}

}
