package p;

public class Consultant extends HourlyWorker {
	private double hourlyPay;
	public static final double CONSULTANT_WAGE = 50.0;
	
	public Consultant() {
		super();
	}
	
	public Consultant(String name, int social) {
		super(name, social);
		hourlyPay = CONSULTANT_WAGE;
	}
	
	public Consultant(String name, int social, double pay) {
		super(name, social);
		
		if( pay > 0.0) {
			hourlyPay = pay;
		}
	}
	public double calculateWeeklyPay() {
		return hourlyPay * 40;
	}
}
